CREATE TABLE [dbo].[segment_analytics_public] (

	[customer_segment] varchar(8000) NULL, 
	[customer_count] bigint NULL
);