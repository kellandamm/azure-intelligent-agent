CREATE TABLE [dbo].[graph_node_categories] (

	[CategoryID] int NULL, 
	[CategoryName] varchar(8000) NULL, 
	[Description] varchar(8000) NULL
);