CREATE TABLE [dbo].[graph_node_product_categories] (

	[ProductCategoryID] int NULL, 
	[ProductCategoryName] varchar(8000) NULL, 
	[Description] varchar(8000) NULL
);