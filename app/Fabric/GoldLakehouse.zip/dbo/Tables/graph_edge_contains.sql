CREATE TABLE [dbo].[graph_edge_contains] (

	[source_id] int NULL, 
	[target_id] int NULL, 
	[Quantity] int NULL, 
	[UnitPrice] decimal(10,2) NULL, 
	[LineTotal] decimal(12,2) NULL
);