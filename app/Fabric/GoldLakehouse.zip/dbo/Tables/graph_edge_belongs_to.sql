CREATE TABLE [dbo].[graph_edge_belongs_to] (

	[source_id] int NULL, 
	[target_id] int NULL, 
	[Price] decimal(10,2) NULL
);