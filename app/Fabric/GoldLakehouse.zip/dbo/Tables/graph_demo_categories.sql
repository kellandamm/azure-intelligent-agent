CREATE TABLE [dbo].[graph_demo_categories] (

	[CategoryID] bigint NULL, 
	[CategoryName] varchar(8000) NULL, 
	[Description] varchar(8000) NULL
);