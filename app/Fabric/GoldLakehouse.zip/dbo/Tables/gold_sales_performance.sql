CREATE TABLE [dbo].[gold_sales_performance] (

	[achievement_pct] float NULL, 
	[actual_value] float NULL, 
	[metric] varchar(8000) NULL, 
	[period] varchar(8000) NULL, 
	[status] varchar(8000) NULL, 
	[target_value] float NULL, 
	[variance] float NULL
);