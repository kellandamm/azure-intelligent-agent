CREATE TABLE [dbo].[gold_customer_category_paths] (

	[CustomerID] int NULL, 
	[FirstName] varchar(8000) NULL, 
	[LastName] varchar(8000) NULL, 
	[State] varchar(8000) NULL, 
	[CategoryID] int NULL, 
	[CategoryName] varchar(8000) NULL, 
	[path_length] int NULL
);