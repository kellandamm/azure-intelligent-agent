CREATE TABLE [dbo].[graph_edge_includes] (

	[source_order_id] int NULL, 
	[target_item_id] int NULL, 
	[Quantity] int NULL, 
	[UnitPrice] decimal(10,2) NULL, 
	[LineTotal] decimal(12,2) NULL
);