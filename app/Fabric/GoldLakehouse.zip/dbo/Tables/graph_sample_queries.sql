CREATE TABLE [dbo].[graph_sample_queries] (

	[query_id] bigint NULL, 
	[query_name] varchar(8000) NULL, 
	[query_text] varchar(8000) NULL
);