CREATE TABLE [dbo].[graph_edge_placed] (

	[source_id] int NULL, 
	[target_id] int NULL, 
	[OrderDate] date NULL, 
	[TotalAmount] decimal(12,2) NULL
);