CREATE TABLE [dbo].[graph_edge_in_category] (

	[source_item_id] int NULL, 
	[target_category_id] int NULL, 
	[Price] decimal(10,2) NULL
);