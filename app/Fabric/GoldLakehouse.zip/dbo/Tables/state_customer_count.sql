CREATE TABLE [dbo].[state_customer_count] (

	[state] varchar(8000) NULL, 
	[customer_count] bigint NULL, 
	[segment_variety] bigint NULL
);