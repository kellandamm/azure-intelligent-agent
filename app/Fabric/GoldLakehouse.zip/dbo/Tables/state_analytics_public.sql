CREATE TABLE [dbo].[state_analytics_public] (

	[state] varchar(8000) NULL, 
	[customer_count] bigint NULL, 
	[vip_count] bigint NULL, 
	[customer_rank] int NULL
);