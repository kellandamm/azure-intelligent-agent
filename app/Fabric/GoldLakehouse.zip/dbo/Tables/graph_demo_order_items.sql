CREATE TABLE [dbo].[graph_demo_order_items] (

	[OrderItemID] bigint NULL, 
	[OrderID] bigint NULL, 
	[ProductID] bigint NULL, 
	[Quantity] bigint NULL, 
	[UnitPrice] float NULL, 
	[LineTotal] float NULL
);