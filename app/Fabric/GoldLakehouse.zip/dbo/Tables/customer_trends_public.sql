CREATE TABLE [dbo].[customer_trends_public] (

	[signup_month] datetime2(6) NULL, 
	[customer_segment] varchar(8000) NULL, 
	[new_customers] bigint NULL
);